<?php
// Start output buffering to avoid any accidental output breaking headers
ob_start();

$response = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect and sanitize form data
    $name    = strip_tags(trim($_POST['name']));
    $email   = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $subject = strip_tags(trim($_POST['subject']));
    $message = trim($_POST['message']);

    // Your email
    $to = "alinaa.zaf@gmail.com";

    // Email headers
    $headers = "From: $name <$email>\r\n";
    $headers .= "Reply-To: $email\r\n";

    // Email body
    $body = "Name: $name\n";
    $body .= "Email: $email\n\n";
    $body .= "Message:\n$message\n";
  // Send email
    if (mail($to, $subject, $body, $headers)) {
        $response = "<div class='alert alert-success'>Message sent successfully!</div>";
    } else {
        $response = "<div class='alert alert-danger'>Failed to send message. Please try again.</div>";
    }
}
?>